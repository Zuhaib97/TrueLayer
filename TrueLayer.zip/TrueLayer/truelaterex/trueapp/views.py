from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .serializer import PokemonSerializer
from .models import Pokemon


# Create your views here.
class PokemonList(APIView):
    def get(self, request):
        pokemon = Pokemon.objects.all()
        query = self.request.GET.get(Pokemon.name)

        if query is not None:
            pokemon = pokemon.filter(name__contains=query) | pokemon.filter(creator__contains=query)
        serializer = PokemonSerializer(pokemon, many=True)
        return Response(serializer.data)
            
